# frozen_string_literal: true

Rails.application.routes.draw do
  root "xml#index"
  # get "lab#output"
end
